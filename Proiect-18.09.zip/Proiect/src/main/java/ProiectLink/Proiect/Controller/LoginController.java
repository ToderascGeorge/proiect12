package ProiectLink.Proiect.Controller;

import ProiectLink.Proiect.Dao.User;
import ProiectLink.Proiect.Dao.UserDao;
import ProiectLink.Proiect.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class LoginController {

    @Autowired
    UserService userService;
    @Autowired
    UserDao userDao;

    @GetMapping("/register-form")
    public ModelAndView registerForm( @RequestParam("email") String email,
                                      @RequestParam("password1") String password1,
                                      @RequestParam("password2") String password2) {
        ModelAndView modelAndView = new ModelAndView("register");

        List<User> userList = userService.getUsersByEmail(email);
        if (!password1.equals(password2)) {
            modelAndView.addObject("message", "parolele nu sunt egale");
        } else {
            //daca sunt corecte, ce fac mai departe?
            userService.save(email, password1);
        }
        if (userList.size() > 0) {
            //daca utilizatorul exista deja in tabela users?
            modelAndView.addObject("message", "Acest email este deja folosit");
            return modelAndView;
        } else {
            //daca nu exista -> pagina produse
            modelAndView = new ModelAndView("redirect:/showProducts");
        }

        return modelAndView;

    }

    @GetMapping("/register")
    public ModelAndView register(){
        return new ModelAndView("register");
    }

        //partea de register-form merge dar dupa ce am scris si partea de login nu a mai mers
        //partea de login nu merge si nu am reusit sa imi dau seama de ce.
    @GetMapping("/login")
    public ModelAndView login(@RequestParam("email")String email,
                              @RequestParam("password")String password){
        ModelAndView modelAndView = new ModelAndView("login");

        List<User> userList = userService.getUsersByEmail(email);
        if (userList.size() == 0) {
            modelAndView.addObject("message", "Userul nu exista");
        }
        if (userList.size() > 1) {
            modelAndView.addObject("message", "User existent");
        }
        if (userList.size() == 1) {
            User userDB = userList.get(0);
            if (!userDB.getPassword().equals(password)) {
                modelAndView.addObject("message", "Parola incorecta");
            } else {
                modelAndView = new ModelAndView("redirect:/dashboard");
            }
        }
        return modelAndView;

    }




    @GetMapping("/cancel")
    public ModelAndView cancel(){
        ModelAndView modelAndView = new ModelAndView("dashboard");

        return modelAndView;
    }


    @GetMapping("/showProducts")
    public ModelAndView produse(){
        ModelAndView modelAndView = new ModelAndView("produse");
        return modelAndView;
    }



    @PostMapping("/saveProdus")
    public ModelAndView saveProdus(@RequestParam("name") String name,
                                   @RequestParam("price") String price,
                                   @RequestParam("linkProduct") String linkProduct){
        ModelAndView modelAndView = new ModelAndView("addProducts");

        //aici trebuie sa iti faci o metoda prin care sa inserezi in bd informatiile din request ale produsului
        System.out.println(name + price + linkProduct);
        return modelAndView;
    }




}

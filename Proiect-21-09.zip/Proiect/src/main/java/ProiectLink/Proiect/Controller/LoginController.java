package ProiectLink.Proiect.Controller;

import ProiectLink.Proiect.Dao.*;
import ProiectLink.Proiect.Exceptions.UserException;
import ProiectLink.Proiect.Security.UserSession;
import ProiectLink.Proiect.Service.ProductService;
import ProiectLink.Proiect.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
public class LoginController {

    @Autowired
    UserSession userSession;
    @Autowired
    UserService userService;
    @Autowired
    ProductService productService;
    @Autowired
    OrderDao orderDao;

    List<Product> productList;


    @GetMapping("/register-form")
    public ModelAndView registerForm( @RequestParam("email") String email,
                                      @RequestParam("password1") String password1,
                                      @RequestParam("password2") String password2) throws UserException {
        ModelAndView modelAndView = new ModelAndView("register");

        List<User> userList = userService.getUsersByEmail(email);
        if (!password1.equals(password2)) {
            modelAndView.addObject("message", "parolele nu sunt egale");
            return modelAndView;
        } else {
            //daca sunt corecte, ce fac mai departe?
            userService.save(email, password1);
        }

        if (userList.size() > 0) {
            //daca utilizatorul exista deja in tabela users?
            modelAndView.addObject("message", "Acest email este deja folosit");
            return modelAndView;
        } else {
            //daca nu exista -> login
            modelAndView = new ModelAndView("redirect:/login");
        }

        return modelAndView;

    }

    @GetMapping("/register")
    public ModelAndView register(){
        return new ModelAndView("register");
    }

    @GetMapping("/login")
    public ModelAndView login(){
        return new ModelAndView("login");
    }


    @GetMapping("/submitLogin")
    public ModelAndView login(@RequestParam("email")String email,
                              @RequestParam("password")String password){
        ModelAndView modelAndView = new ModelAndView("login");

        List<User> userList = userService.getUsersByEmail(email);
        if (userList.size() == 0) {
            modelAndView.addObject("message", "Userul nu exista");
        }
        if (userList.size() > 1) {
            modelAndView.addObject("message", "User existent");
        }
        if (userList.size() == 1) {
            User userDB = userList.get(0);
            if (!userDB.getPassword().equals(password)) {
                modelAndView.addObject("message", "Parola incorecta");
                return modelAndView;
            } else {
                userSession.setId(userDB.getId());
            }
        }
        return new ModelAndView("redirect:index.html");

    }

    @GetMapping("/cancel")
    public ModelAndView cancel(){
        ModelAndView modelAndView = new ModelAndView("dashboard");

        return modelAndView;
    }
    @GetMapping("/showProducts")
    public ModelAndView produse(){
        ModelAndView modelAndView = new ModelAndView("produse");
        return modelAndView;
    }

    @GetMapping("/addProducts")
        public ModelAndView addproducts() {
        ModelAndView modelAndView = new ModelAndView("addProducts");
        return modelAndView;
    }

    //aici trebuie sa iti faci o metoda prin care sa inserezi in bd informatiile din request ale produsului
    @PostMapping("/saveProdus")
    public ModelAndView saveProdus(@RequestParam("name") String name,
                                   @RequestParam("price") Double price,
                                   @RequestParam("linkProduct") String linkProduct){
        ModelAndView modelAndView = new ModelAndView("addProducts");

        productService.addProduct(name,price,linkProduct);
        modelAndView.addObject("message", "Produsul" + name + "in valoare de: "+ price + "a fost adaugat" );
        return modelAndView;
    }


    @GetMapping("/viewProduse")
    public ModelAndView viewProducts(){
        ModelAndView modelAndView =
                new ModelAndView("produse");
        List<Product> productList = productService.getAllProducts();
        modelAndView.addObject("products", productList);
        return modelAndView;
    }

    @PostMapping("/addToCart")
    public ModelAndView addToCart(@RequestParam("productId") Integer id) {
        ModelAndView modelAndView = new ModelAndView("produse");
        modelAndView.addObject("products", productList);


        return new ModelAndView("redirect:/viewProduse");
    }

    @GetMapping("/cos")
    public ModelAndView cos(){
        ModelAndView modelAndView = new ModelAndView("cos");
        return modelAndView;
    }

    @PostMapping("/showCart")
    public ModelAndView showCart() {
        ModelAndView modelAndView = new ModelAndView("cos");

        List<CartProduct> cartProducts = new ArrayList<>();
        for (Map.Entry<Integer,Integer> entry:userSession.getShoppingCart().entrySet()) {
            int productId = entry.getKey();
            int quantity =entry.getValue();
            Product product = productService.findById(productId);

            CartProduct cartProduct = new CartProduct();
            cartProduct.setId(productId);
            cartProduct.setName(product.getName());
            cartProduct.setCartQuantity(quantity);
            cartProduct.setCartSum(quantity * product.getPrice());

            cartProducts.add(cartProduct);

        }
        modelAndView.addObject("cartList", cartProducts);
        return modelAndView;
    }


    @GetMapping("/buyCart")
    public ModelAndView modelAndView() {
        ModelAndView modelAndView = new ModelAndView("order");

        List<OrderLines> orderLines = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : userSession.getShoppingCart().entrySet()) {
            int productId = entry.getKey();
            int quantity = entry.getValue();
            Product product = productService.findById(productId);

            OrderLines orderLines1 = new OrderLines();
            orderLines1.setProductId(productId);
            orderLines1.setQuantity(quantity);
            orderLines1.setPrice(product.getPrice() * quantity);

            orderLines.add(orderLines1);


        }
        Order order = new Order();
        order.setUserId(userSession.getId());
        order.setOrderLines(orderLines);
        orderDao.save(order);
        userSession.getShoppingCart().clear();
        return modelAndView;
    }


}

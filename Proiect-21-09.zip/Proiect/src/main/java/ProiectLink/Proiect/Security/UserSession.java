package ProiectLink.Proiect.Security;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import java.util.HashMap;

@SessionScope
@Component
public class UserSession {
    private int id;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }


    private HashMap<Integer, Integer> shoppingCart = new HashMap<>();

    public HashMap<Integer, Integer> getShoppingCart() {
        return shoppingCart;
    }

    public void setShoppingCart(HashMap<Integer, Integer> shoppingCart) {
        this.shoppingCart = shoppingCart;
    }

    public void addToCart(int id) {
        if (shoppingCart.get(id) != null) {
            int currentQuantity = shoppingCart.get(id);
            int newQuantity = currentQuantity + 1;
            shoppingCart.put(id, newQuantity);

        } else {
            shoppingCart.put(id, 1);
        }

    }
}

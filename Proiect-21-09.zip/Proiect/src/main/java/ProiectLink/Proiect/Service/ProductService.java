package ProiectLink.Proiect.Service;

import ProiectLink.Proiect.Dao.Product;
import ProiectLink.Proiect.Dao.ProductDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {


    @Autowired
    ProductDao productDao;

    public String addProduct(String name, Double price , String linkProduct){

        Product product = new Product();
        product.setName(name);
        product.setPrice(price);
        product.setLinkProduct(linkProduct);
        productDao.save(product);

        return "Produsul " + product.getName() + " a fost salvat cu succes";

    }

    public List<Product> getAllProducts(){
        return (List<Product>) productDao.findAll();
    }


    public Product findById(int id){
        return productDao.findById(id).get();

    }
}

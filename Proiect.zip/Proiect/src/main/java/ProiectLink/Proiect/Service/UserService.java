package ProiectLink.Proiect.Service;


import ProiectLink.Proiect.Dao.User;
import ProiectLink.Proiect.Dao.UserDao;
import ProiectLink.Proiect.Exceptions.UserException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    UserDao userDao;

    public void save(String email, String password){
        User user = new User();
        user.setEmail(email);
        user.setPassword(password);
        userDao.save(user);
    }

    public void checkPassword( String password, String password2 ) throws UserException {
        if (!password.equals(password2)){
            throw new UserException("parolele nu sunt egale din exceptie");
        }


    }

    public static List<User> getUsersByEmail(String email){

        return UserDao.findByEmail(email);
    }
}

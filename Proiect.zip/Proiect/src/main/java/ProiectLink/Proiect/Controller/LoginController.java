package ProiectLink.Proiect.Controller;

import ProiectLink.Proiect.Dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

    @Autowired
    UserDao userDao;

    @GetMapping("/register-form")
    public ModelAndView registerForm( @RequestParam("email") String email, @RequestParam("password1") String password1, @RequestParam("password2") String password2) {
        ModelAndView modelAndView = new ModelAndView("register");

        if (!password1.equals(password2)) {
            modelAndView.addObject("message", "parolele nu sunt corecte");
        } else {
            //daca sunt corecte, ce fac mai departe?
            //daca utilizatorul exista deja in tabela users?
            //daca nu exista -> pagina produse

        }


        return modelAndView;

    }

    @GetMapping("/register")
    public ModelAndView register(){

        return new ModelAndView("register");
    }


    @GetMapping("/login")
    public ModelAndView login(){
        ModelAndView modelAndView = new ModelAndView("login");

        return modelAndView;
    }




    @GetMapping("/cancel")
    public ModelAndView cancel(){
        ModelAndView modelAndView = new ModelAndView("dashboard");

        return modelAndView;
    }


    @GetMapping("/showProducts")
    public ModelAndView produse(){
        ModelAndView modelAndView = new ModelAndView("produse");
        return modelAndView;
    }



    @GetMapping("/addProdus")
    public ModelAndView modelAndView(){
        ModelAndView modelAndView = new ModelAndView("addProducts");
        return modelAndView;
    }



}
